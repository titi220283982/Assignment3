 /**
 *
 * @author TITILAYO AKINJOLE 220283982
 */
package za.ac.cput.assignment3;

import java.io.FileWriter;
import java.io.IOException;

public class WriteCustomer {
    public static void main(String[] args) {
    try {
      FileWriter myWriter = new FileWriter("customerOutFile.txt");
      myWriter.write("================== CUSTOMERS =======================" + System.getProperty("line.separator"));
      myWriter.write("ID   Name       Surname    Date of birth   Age" + System.getProperty("line.separator"));
      myWriter.write("====================================================" + System.getProperty("line.separator"));
      myWriter.write("C100 Mike       Rohsopht    24 Jan 1993    28" + System.getProperty("line.separator"));
      myWriter.write("C130 Stu        Padassol    18 May 1987    34" + System.getProperty("line.separator"));
      myWriter.write("C150 Luke       Atmyass     27 Jan 1981    40" + System.getProperty("line.separator"));
      myWriter.write("C250 Eileen     Sideways    27 Nov 1999    21" + System.getProperty("line.separator"));
      myWriter.write("C260 Ima        Stewpidas   27 Jan 2001    20" + System.getProperty("line.separator"));
      myWriter.write("C300 Ivana.B    Withew      16 Jul 1998    22" + System.getProperty("line.separator"));
      myWriter.write("                                                " + System.getProperty("line.separator"));
      myWriter.write("Number of customers who can rent: 4" + System.getProperty("line.separator"));
      myWriter.write("Number of customers who cannot rent: 2" + System.getProperty("line.separator"));
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}