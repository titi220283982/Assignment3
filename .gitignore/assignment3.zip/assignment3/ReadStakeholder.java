/**
 *
 * @author TITILAYO AKINJOLE 220283982
 */
package za.ac.cput.assignment3;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;


public class ReadStakeholder {
    public static void main(String[] args) {
		List lst = new ArrayList();
		

		try {
            FileInputStream fis = new FileInputStream("./stakeholder.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            lst = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
            
            //Print list data
            for(Object str: lst){
                System.out.println(str);
            }            
            
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}

	}

}
