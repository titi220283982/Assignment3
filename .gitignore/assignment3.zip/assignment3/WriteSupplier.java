/**
 *
 * @author TITILAYO AKINJOLE 220283982
 */

package za.ac.cput.assignment3;

import java.io.FileWriter;
import java.io.IOException;


public class WriteSupplier {
     public static void main(String[] args) {
    try {
      FileWriter myWriter;
        myWriter = new FileWriter("supplierOutFile.txt");
      myWriter.write("================== SUPPLIERS ==========================" + System.getProperty("line.separator"));
      myWriter.write("ID      Name                Prod Type  Description" + System.getProperty("line.separator"));
      myWriter.write("=======================================================" + System.getProperty("line.separator"));
      myWriter.write("S350    Auto Delight        BMW        Luxury SUV" + System.getProperty("line.separator"));
      myWriter.write("S270    Grand Theft Auto    Toyota     Mid-size sedan" + System.getProperty("line.separator"));
      myWriter.write("S290    MotorMania          Hyundai    compact budget" + System.getProperty("line.separator"));
      myWriter.write("S400    Prime Motors        Lexus      Luxury sedan" + System.getProperty("line.separator"));
      myWriter.write("S300    We got Cars         Toyota     10-seater minibus" + System.getProperty("line.separator"));
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
    }
  }
}